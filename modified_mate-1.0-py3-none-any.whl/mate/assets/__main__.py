#!/usr/bin/env python3

"""Print the path to mate's assets directory and exit."""

import mate


print(mate.ASSETS_DIR)
