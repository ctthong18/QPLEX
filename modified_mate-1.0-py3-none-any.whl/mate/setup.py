from setuptools import setup, find_packages
 
setup(
    name="modified_mate", #Name
    version="1.0", #Version
    packages = find_packages()  # Automatically find the packages that are recognized in the '__init__.py'.
)