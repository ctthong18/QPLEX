"""MATE: The Multi-Agent Tracking Environment."""

__version__ = '0.1.0'
__license__ = 'MIT'
__author__ = __maintainer__ = 'Xuehai Pan'
__email__ = 'XuehaiPan@pku.edu.cn'
